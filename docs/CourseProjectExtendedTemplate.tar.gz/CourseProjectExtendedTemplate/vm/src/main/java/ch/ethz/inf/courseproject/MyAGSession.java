/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ch.ethz.inf.courseproject;

import com.meaningfulmodels.actiongui.vm.core.AGSession;

/**
 *
 */
public class MyAGSession implements AGSession {

    @Override
    public String getCallerId() {
        return null;
    }

    @Override
    public String getRoleId() {
        return null;
    }

    @Override
    public void logout() {
    }
}
